import { useState } from 'react';
import { LayoutDashboard, Wrench } from 'lucide-react';
import { useAuth } from '../../auth/context/AuthContext';
import { Role } from '../../../types';
import Dashboard from './Dashboard';
import DashboardOperativo from './DashboardOperativo';

/**
 * OPERADOR → siempre ve DashboardOperativo, sin toggle
 * SUPERVISOR / ADMIN / SUPERADMIN → pueden alternar entre ambos
 */
const DashboardRouter: React.FC = () => {
  const { user } = useAuth();
  const isOperador = user?.role === Role.OPERADOR;
  const [view, setView] = useState<'completo' | 'operativo'>(
    isOperador ? 'operativo' : 'completo'
  );

  if (isOperador) {
    return <DashboardOperativo />;
  }

  return (
    <div>
      {/* Toggle — solo visible para roles superiores */}
      <div className="flex items-center gap-1 mb-4 w-fit">
        <button
          onClick={() => setView('completo')}
          className="flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-bold transition-all"
          style={{
            background: view === 'completo' ? 'var(--accent-primary)' : 'var(--bg-card)',
            color: view === 'completo' ? '#fff' : 'var(--text-secondary)',
            border: '1px solid var(--border-primary)',
          }}
        >
          <LayoutDashboard size={13} />
          Gerencial
        </button>
        <button
          onClick={() => setView('operativo')}
          className="flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-bold transition-all"
          style={{
            background: view === 'operativo' ? 'var(--accent-primary)' : 'var(--bg-card)',
            color: view === 'operativo' ? '#fff' : 'var(--text-secondary)',
            border: '1px solid var(--border-primary)',
          }}
        >
          <Wrench size={13} />
          Operativo
        </button>
      </div>

      {view === 'completo' ? <Dashboard /> : <DashboardOperativo />}
    </div>
  );
};

export default DashboardRouter;
