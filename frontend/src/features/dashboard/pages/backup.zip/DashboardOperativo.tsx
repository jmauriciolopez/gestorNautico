import React from 'react';
import { Ship, Navigation, Activity, MapPin, ArrowUpRight, Anchor } from 'lucide-react';
import { useRackMap } from '../hooks/useDashboard';
import { MapaRacks } from '../components/MapaRacks';
import { useEmbarcaciones } from '../../embarcaciones/hooks/useEmbarcaciones';
import { useOperaciones } from '../../operaciones/hooks/useOperaciones';
import { useAuth } from '../../auth/context/AuthContext';
import { useNavigate } from 'react-router-dom';
import { useState } from 'react';
import { toast } from 'react-hot-toast';

const DashboardOperativo: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [is3D, setIs3D] = useState(false);

  const { data: rackMapData, isLoading: isMapLoading } = useRackMap();
  const { getEmbarcaciones, updateEmbarcacion } = useEmbarcaciones();
  const { getMovimientos } = useOperaciones();

  const embarcaciones = getEmbarcaciones.data || [];
  const movimientos = getMovimientos.data || [];

  const enCuna = embarcaciones.filter(e => e.estado === 'EN_CUNA').length;
  const enAgua = embarcaciones.filter(e => e.estado === 'EN_AGUA').length;
  const libres = embarcaciones.filter(e => !e.espacioId && e.estado !== 'INACTIVA').length;

  const movimientosHoy = movimientos.filter(m => {
    const fecha = new Date(m.fecha);
    const hoy = new Date();
    return fecha.toDateString() === hoy.toDateString();
  });

  const handleAsignarBarco = async (embarcacionId: number, espacioId: number) => {
    try {
      await updateEmbarcacion.mutateAsync({ id: embarcacionId, data: { espacioId } });
      toast.success('Embarcación asignada');
    } catch (error: any) {
      toast.error(error.message || 'Error al asignar');
    }
  };

  return (
    <div className="space-y-4 animate-in fade-in duration-500">

      {/* Header */}
      <div
        className="flex items-center justify-between p-5 rounded-2xl"
        style={{ background: 'var(--bg-card)', border: '1px solid var(--border-primary)' }}
      >
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-[10px] font-bold text-emerald-500 uppercase tracking-widest">Turno activo</span>
          </div>
          <h1 className="text-xl font-black" style={{ color: 'var(--text-primary)' }}>
            Hola, {user?.nombre}
          </h1>
          <p className="text-xs mt-0.5" style={{ color: 'var(--text-secondary)' }}>
            {new Date().toLocaleDateString('es-AR', { weekday: 'long', day: 'numeric', month: 'long' })}
          </p>
        </div>
        <button
          onClick={() => navigate('/operaciones')}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold text-white transition-all active:scale-95"
          style={{ background: 'var(--accent-primary)' }}
        >
          <Navigation size={14} />
          Nueva Operación
        </button>
      </div>

      {/* Stats rápidas */}
      <div className="grid grid-cols-3 gap-3">
        {[
          { label: 'En Cuna', value: enCuna, icon: Anchor, color: '#f59e0b' },
          { label: 'En Agua', value: enAgua, icon: Ship, color: '#6366f1' },
          { label: 'Sin Ubicar', value: libres, icon: MapPin, color: '#10b981' },
        ].map(({ label, value, icon: Icon, color }) => (
          <div
            key={label}
            className="p-4 rounded-2xl flex flex-col gap-2"
            style={{ background: 'var(--bg-card)', border: '1px solid var(--border-primary)' }}
          >
            <Icon size={18} style={{ color }} />
            <span className="text-2xl font-black" style={{ color: 'var(--text-primary)' }}>{value}</span>
            <span className="text-[10px] font-bold uppercase tracking-widest" style={{ color: 'var(--text-muted)' }}>{label}</span>
          </div>
        ))}
      </div>

      {/* Mapa de racks */}
      <div
        className="rounded-2xl overflow-hidden"
        style={{ border: '1px solid var(--border-primary)' }}
      >
        <div
          className="flex items-center justify-between px-5 py-3"
          style={{ borderBottom: '1px solid var(--border-primary)', background: 'var(--bg-card)' }}
        >
          <span className="text-xs font-black uppercase tracking-widest" style={{ color: 'var(--text-primary)' }}>
            Mapa de Espacios
          </span>
          <button
            onClick={() => setIs3D(!is3D)}
            className="text-[10px] font-bold px-3 py-1.5 rounded-lg transition-all"
            style={{
              background: is3D ? 'var(--accent-primary)' : 'var(--bg-primary)',
              color: is3D ? '#fff' : 'var(--text-secondary)',
              border: '1px solid var(--border-primary)',
            }}
          >
            {is3D ? '3D Activo' : 'Vista 3D'}
          </button>
        </div>
        <div style={{ background: 'var(--bg-primary)' }}>
          {isMapLoading ? (
            <div className="h-64 flex items-center justify-center">
              <div className="w-8 h-8 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin" />
            </div>
          ) : (
            <MapaRacks
              data={rackMapData || []}
              embarcacionesLibres={embarcaciones.filter(e => !e.espacioId && e.estado !== 'INACTIVA')}
              onAsignar={handleAsignarBarco}
              is3D={is3D}
            />
          )}
        </div>
      </div>

      {/* Movimientos del día */}
      <div
        className="rounded-2xl"
        style={{ background: 'var(--bg-card)', border: '1px solid var(--border-primary)' }}
      >
        <div
          className="flex items-center justify-between px-5 py-3"
          style={{ borderBottom: '1px solid var(--border-primary)' }}
        >
          <span className="text-xs font-black uppercase tracking-widest" style={{ color: 'var(--text-primary)' }}>
            Movimientos de hoy
          </span>
          <span
            className="text-[10px] font-bold px-2 py-1 rounded-lg"
            style={{ background: 'var(--bg-primary)', color: 'var(--text-secondary)' }}
          >
            {movimientosHoy.length} registros
          </span>
        </div>
        <div className="divide-y" style={{ borderColor: 'var(--border-secondary)' }}>
          {movimientosHoy.length === 0 ? (
            <div className="py-10 text-center">
              <Activity size={24} className="mx-auto mb-2 opacity-20" style={{ color: 'var(--text-muted)' }} />
              <p className="text-xs" style={{ color: 'var(--text-muted)' }}>Sin movimientos hoy</p>
            </div>
          ) : (
            movimientosHoy.slice(0, 8).map(m => (
              <div key={m.id} className="flex items-center justify-between px-5 py-3">
                <div className="flex items-center gap-3">
                  <div
                    className="w-7 h-7 rounded-lg flex items-center justify-center"
                    style={{
                      background: m.tipo === 'entrada' ? 'rgba(16,185,129,0.1)' : 'rgba(99,102,241,0.1)',
                    }}
                  >
                    {m.tipo === 'entrada'
                      ? <ArrowUpRight size={14} style={{ color: '#10b981' }} />
                      : <ArrowUpRight size={14} style={{ color: '#6366f1', transform: 'rotate(180deg)' }} />
                    }
                  </div>
                  <div>
                    <p className="text-xs font-bold" style={{ color: 'var(--text-primary)' }}>
                      {m.embarcacion?.nombre}
                    </p>
                    <p className="text-[10px]" style={{ color: 'var(--text-muted)' }}>
                      {m.tipo === 'entrada' ? 'Entrada a cuna' : 'Salida al agua'}
                    </p>
                  </div>
                </div>
                <span className="text-[10px] font-mono" style={{ color: 'var(--text-muted)' }}>
                  {new Date(m.fecha).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

export default DashboardOperativo;
